/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jan 7, 2015 4:36:59 PM                      ---
 * ----------------------------------------------------------------
 */
package com.accenture.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedDataremovaladdonConstants
{
	public static final String EXTENSIONNAME = "dataremovaladdon";
	
	protected GeneratedDataremovaladdonConstants()
	{
		// private constructor
	}
	
	
}
