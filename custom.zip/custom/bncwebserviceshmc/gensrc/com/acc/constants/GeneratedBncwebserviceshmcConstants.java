/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jan 5, 2015 4:45:55 PM                      ---
 * ----------------------------------------------------------------
 */
package com.acc.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedBncwebserviceshmcConstants
{
	public static final String EXTENSIONNAME = "bncwebserviceshmc";
	
	protected GeneratedBncwebserviceshmcConstants()
	{
		// private constructor
	}
	
	
}
