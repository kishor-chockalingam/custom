package com.acc.test.groovy.webservicetests

import groovy.json.JsonSlurper

import static com.acc.test.groovy.webservicetests.TestUtil.verifyXML

import com.acc.test.groovy.webservicetests.markers.AvoidCollectingOutputFromTest
import com.acc.test.groovy.webservicetests.markers.CollectOutputFromTest

import org.junit.Test
import org.junit.experimental.categories.Category


@Category(CollectOutputFromTest.class)
class CartTests extends BaseWSTest {

    static final PASSWORD = "test"
    static final RESTRICTED_PROMOTION_CODE = "WS_RestrictedOrderThreshold15Discount"
    static final PROMOTION_VOUCHER_CODE = "abc-9PSW-EDH2-RXKA";
    static final RESTRICTED_PROMOTION_VOUCHER_CODE = "abr-D7S5-K14A-51Y5"
    static final ABSOLUTE_VOUCHER_CODE = "xyz-MHE2-B8L5-LPHE";
    static final NOT_EXISTING_VOUCHER_CODE = "notExistingVoucher";
    static final RESTRICTED_PROMOTION_TYPE = 'Order threshold fixed discount'
    static final RESTRICTED_PROMOTION_FIRED_MESSAGE = 'You saved $20.00 for spending over $200.00'
    static final RESTRICTED_PROMOTION_COULD_FIRE_MESSAGE = 'Spend $200.00 to get a discount of $20.00 - Spend another $200.00 to qualify'
    static final RESTRICTED_PROMOTION_DESCRIPTION = 'You saved bunch of bucks for spending quite much'
    static final RESTRICTED_PROMOTION_END_DATE = '2099-01-01T00:00:00'

    final @Test
    void testGetCartJSON() {
        def con = TestUtil.getConnection("/cart", 'GET', 'JSON', HttpURLConnection.HTTP_OK)

        def response = TestUtil.verifiedJSONSlurper(con)
        assert response.totalItems == 0
        assert response.totalUnitCount == 0
        assert response.net == false
        assert response.calculated == false
        assert response.totalPrice.currencyIso == 'USD'
        assert response.totalPrice.priceType == 'BUY'
        assert response.totalPrice.value == 0
        assert response.totalPrice.formattedValue == '$0.00'
        assert response.subTotal.currencyIso == 'USD'
        assert response.subTotal.priceType == 'BUY'
        assert response.subTotal.value == 0
        assert response.subTotal.formattedValue == '$0.00'
    }

    @Test
    void testGetCartXML() {
        def con = TestUtil.getConnection("/cart", 'GET', 'XML', HttpURLConnection.HTTP_OK)

        def response = TestUtil.verifiedXMLSlurper(con)
        assert response.name() == 'cart'
        assert response.totalItems == 0
        assert response.totalUnitCount == 0
        assert response.net == 'false'
        assert response.calculated == false
        assert response.totalPrice.currencyIso == 'USD'
        assert response.totalPrice.priceType == 'BUY'
        assert response.totalPrice.value == 0
        assert response.totalPrice.formattedValue == '$0.00'
        assert response.subTotal.currencyIso == 'USD'
        assert response.subTotal.priceType == 'BUY'
        assert response.subTotal.value == 0
        assert response.subTotal.formattedValue == '$0.00'
    }

    @Test
    //@Category(AvoidCollectingOutputFromTest.class)
    void testGetCartAfterCurrencyChangeXML() {
        def con, body, response, cookieNoPath

        //create customer and cart
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)
        def aid = customerTests.createAddress(access_token)

        //add something to a cart
        cookieNoPath = addToCart(3429337)
        //println cookieNoPath

        con = TestUtil.getConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath)

        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)

        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.totalPrice.value == 11.12
        assert response.totalPrice.formattedValue == '$11.12'
        assert response.totalPrice.currencyIso == 'USD'
        assert response.totalPrice.priceType == 'BUY'

        //=============================

        con = TestUtil.getConnection('/cart?curr=JPY', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath)

        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)

        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.totalPrice.value == 940.0
        assert response.totalPrice.formattedValue == '¥940'
        assert response.totalPrice.currencyIso == 'JPY'

        con = TestUtil.getConnection('/cart?curr=USD', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath)

        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)

        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.totalPrice.value == 11.12
        assert response.totalPrice.formattedValue == '$11.12'
        assert response.totalPrice.currencyIso == 'USD'
    }

    @Test
    void testAddToCart() {
        def con, response, cookieNoPath

        // create anonymous cart
        cookieNoPath = addToCart(3429337)

        // get the cart
        con = TestUtil.getConnection('/cart', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        response = TestUtil.verifiedJSONSlurper(con, false, false)
        assert response.store == 'wsTest'
        assert response.appliedOrderPromotions != null
        assert response.net == false
        assert response.calculated == true
        assert response.appliedVouchers != null
        assert response.productDiscounts.currencyIso == 'USD'
        assert response.productDiscounts.priceType == 'BUY'
        assert response.productDiscounts.value == 0.0
        assert response.productDiscounts.formattedValue == '$0.00'
        assert response.totalDiscounts.currencyIso == 'USD'
        assert response.totalDiscounts.priceType == 'BUY'
        assert response.totalDiscounts.value == 0.0
        assert response.totalDiscounts.formattedValue == '$0.00'
        assert response.subTotal.currencyIso == 'USD'
        assert response.subTotal.priceType == 'BUY'
        assert response.subTotal.value == 11.12
        assert response.subTotal.formattedValue == '$11.12'
        assert response.orderDiscounts.currencyIso == 'USD'
        assert response.orderDiscounts.priceType == 'BUY'
        assert response.orderDiscounts.value == 0.0
        assert response.orderDiscounts.formattedValue == '$0.00'
        assert response.entries.product[0].code == '3429337'
        assert response.entries[0].entryNumber == 0
        assert response.entries[0].quantity == 1
        assert response.appliedProductPromotions != null
        assert response.totalPrice.currencyIso == 'USD'
        assert response.totalPrice.priceType == 'BUY'
        assert response.totalPrice.value == 11.12
        assert response.totalPrice.formattedValue == '$11.12'
        assert response.site == 'wsTest'
        assert response.code
        assert response.guid
        assert response.totalItems == 1
        assert response.totalPriceWithTax.currencyIso == 'USD'
        assert response.totalPriceWithTax.priceType == 'BUY'
        assert response.totalPriceWithTax.value == 11.12
        assert response.totalPriceWithTax.formattedValue == '$11.12'
        assert response.totalTax.currencyIso == 'USD'
        assert response.totalTax.priceType == 'BUY'
        assert response.totalTax.value == 0.0
        assert response.totalTax.formattedValue == '$0.00'
        assert response.potentialProductPromotions != null
        assert response.potentialOrderPromotions != null
        assert response.totalUnitCount == 1
    }

    @Test
    void testUpdateCartEntry() {
        def con, body, response, cookieNoPath

        // create anonymous cart
        cookieNoPath = addToCart(3429337)

        // get the cart
        con = TestUtil.getConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.totalPrice.value == 11.12

        // update cart entry
        con = TestUtil.getConnection('/cart/entry/0?qty=3', 'PUT', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.name() == 'cartModification'
        assert response.statusCode == 'success'
        assert response.entry[0].product.code == '3429337'
        assert response.entry[0].entryNumber == 0
        assert response.entry[0].updateable == true
        assert response.entry[0].quantity == 3
        assert response.entry[0].basePrice.currencyIso == 'USD'
        assert response.entry[0].basePrice.priceType == 'BUY'
        assert response.entry[0].basePrice.value == 11.12
        assert response.entry[0].basePrice.formattedValue == '$11.12'
        assert response.entry[0].totalPrice.currencyIso == 'USD'
        assert response.entry[0].totalPrice.priceType == 'BUY'
        assert response.entry[0].totalPrice.value == 33.36
        assert response.entry[0].totalPrice.formattedValue == '$33.36'
        assert response.quantity == 3
        assert response.quantityAdded == 2

        // get updated cart
        con = TestUtil.getConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 3
        assert response.totalPrice.value == 33.36
    }

    @Test
    void testRemoveCartEntry() {
        def con, response, cookieNoPath

        // create anonymous cart
        cookieNoPath = addToCart(3429337, 2)
        cookieNoPath = addToCart(1225694, 1, cookieNoPath)

        // get the cart
        con = TestUtil.getConnection('/cart', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        response = TestUtil.verifiedJSONSlurper(con, false, false)
        assert response.totalItems == 2
        assert response.totalUnitCount == 3
        assert response.totalPrice.value == 869.98

        // remove cart entry
        con = TestUtil.getConnection('/cart/entry/1', 'DELETE', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        response = TestUtil.verifiedJSONSlurper(con, false, false)
        assert response.statusCode == 'success'
        assert response.quantity == 0
        assert response.quantityAdded == -1

        // check the cart
        con = TestUtil.getConnection('/cart', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        response = TestUtil.verifiedJSONSlurper(con, false, false)
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 22.24
    }

    @Test
    void testClientCartRestorationByGuid() {
        def con, body, response, cookie, cookieNoPath

        // create anonymous cart
        cookieNoPath = addToCart(3429337, 2)

        // get the cart and save guid
        con = TestUtil.getConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.guid: "No guid present, cannot restore cart"
        def guid = response.guid

        def access_token = TestUtil.getClientCredentialsToken()

        // restore cart
        con = TestUtil.getSecureConnection("/cart/restore?guid=${guid}", 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        println body
        verifyXML(body)
        // check for cookie, extract it for next request
        cookie = con.getHeaderField('Set-Cookie')
        println cookie
        assert cookie: 'No cookie present, cannot keep session'
        cookieNoPath = cookie.split(';')[0]

        // check cart restoration
        con = TestUtil.getConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
    }

    @Test
    void testAutomaticallyCartRestoration() {
        def con, body, response, cookieNoPath

        //create customer and cart
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)
        cookieNoPath = addToCart(3429337, 2, null, access_token)

        //logout
        con = TestUtil.getSecureConnection(TestUtil.LOGOUT_URL, 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.logout.success

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)

        assert response.totalItems == 1
        assert response.totalUnitCount == 2
    }

    @Test
    void testDisabledAutomaticallyCartRestoration() {
        def con, body, response, cookieNoPath

        //create customer and cart
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)
        cookieNoPath = addToCart(3429337, 2, null, access_token)

        //logout
        con = TestUtil.getSecureConnection(TestUtil.LOGOUT_URL, 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.logout.success

        con = TestUtil.getSecureConnection('/cart?restore=false', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)

        assert response.totalItems == 0
        assert response.totalUnitCount == 0
    }

    @Test
    void testEnableOrderPromotionByClient() {
        def con, body, response, cookie, cookieNoPath
        def access_token = TestUtil.getClientCredentialsToken()

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        verifyXML(body)
        cookie = con.getHeaderField('Set-Cookie')
        assert cookie: 'No cookie present, cannot keep session'
        cookieNoPath = cookie.split(';')[0]

        addToCart(1225694, 1, cookieNoPath, access_token)

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        println body
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult[0].promotion.code == RESTRICTED_PROMOTION_CODE
        assert response.appliedOrderPromotions.promotionResult[0].promotion.firedMessages.string == RESTRICTED_PROMOTION_FIRED_MESSAGE
        assert response.appliedOrderPromotions.promotionResult[0].promotion.promotionType == RESTRICTED_PROMOTION_TYPE
        assert response.appliedOrderPromotions.promotionResult[0].promotion.description == RESTRICTED_PROMOTION_DESCRIPTION
        assert response.appliedOrderPromotions.promotionResult[0].promotion.endDate.toString().startsWith(RESTRICTED_PROMOTION_END_DATE)
        assert response.appliedOrderPromotions.promotionResult[0].description == RESTRICTED_PROMOTION_FIRED_MESSAGE
    }


    @Test
    void testDisableOrderPromotionByClient() {
        def con, body, response, cookie, cookieNoPath
        def access_token = TestUtil.getClientCredentialsToken()

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        verifyXML(body)
        cookie = con.getHeaderField('Set-Cookie')
        assert cookie: 'No cookie present, cannot keep session'
        cookieNoPath = cookie.split(';')[0]

        addToCart(1225694, 1, cookieNoPath, access_token)

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 1

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'DELETE', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0
    }

    @Test
    void testEnablePotentialOrderPromotionByClient() {
        def con, body, response, cookie, cookieNoPath
        def access_token = TestUtil.getClientCredentialsToken()

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        verifyXML(body)
        cookie = con.getHeaderField('Set-Cookie')
        println cookie
        assert cookie: 'No cookie present, cannot keep session'
        cookieNoPath = cookie.split(';')[0]

        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult[0].promotion.code == RESTRICTED_PROMOTION_CODE
        assert response.potentialOrderPromotions.promotionResult[0].promotion.promotionType == RESTRICTED_PROMOTION_TYPE
        assert response.potentialOrderPromotions.promotionResult[0].promotion.description == RESTRICTED_PROMOTION_DESCRIPTION
        assert response.potentialOrderPromotions.promotionResult[0].promotion.endDate.toString().startsWith(RESTRICTED_PROMOTION_END_DATE)
        assert response.potentialOrderPromotions.promotionResult[0].promotion.couldFireMessages.string == RESTRICTED_PROMOTION_COULD_FIRE_MESSAGE
        assert response.potentialOrderPromotions.promotionResult[0].description == RESTRICTED_PROMOTION_COULD_FIRE_MESSAGE
    }

    @Test
    void testDisablePotentialOrderPromotionByClient() {
        def con, body, response, cookie, cookieNoPath
        def access_token = TestUtil.getClientCredentialsToken()

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        verifyXML(body)
        cookie = con.getHeaderField('Set-Cookie')
        println cookie
        assert cookie: 'No cookie present, cannot keep session'
        cookieNoPath = cookie.split(';')[0]

        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 1

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'DELETE', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0
    }

    @Test
    void testEnableOrderPromotionByCustomer() {
        def con, body, response, cookie, cookieNoPath
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        verifyXML(body)
        cookie = con.getHeaderField('Set-Cookie')
        println cookie
        assert cookie: 'No cookie present, cannot keep session'
        cookieNoPath = cookie.split(';')[0]

        addToCart(1225694, 1, cookieNoPath, access_token)

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult[0].promotion.code == RESTRICTED_PROMOTION_CODE
        assert response.appliedOrderPromotions.promotionResult[0].promotion.firedMessages.string == RESTRICTED_PROMOTION_FIRED_MESSAGE
        assert response.appliedOrderPromotions.promotionResult[0].promotion.promotionType == RESTRICTED_PROMOTION_TYPE
        assert response.appliedOrderPromotions.promotionResult[0].promotion.description == RESTRICTED_PROMOTION_DESCRIPTION
        assert response.appliedOrderPromotions.promotionResult[0].promotion.endDate.toString().startsWith(RESTRICTED_PROMOTION_END_DATE)
        assert response.appliedOrderPromotions.promotionResult[0].description == RESTRICTED_PROMOTION_FIRED_MESSAGE
    }

    @Test
    void testDisableOrderPromotionByCustomer() {
        def con, body, response, cookie, cookieNoPath
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        verifyXML(body)
        cookie = con.getHeaderField('Set-Cookie')
        println cookie
        assert cookie: 'No cookie present, cannot keep session'
        cookieNoPath = cookie.split(';')[0]

        addToCart(1225694, 1, cookieNoPath, access_token)

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 1

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'DELETE', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.totalItems == 1
        assert response.totalUnitCount == 1
        assert response.appliedOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0
    }

    @Test
    void testEnablePotentialOrderPromotionByCustomer() {
        def con, body, response, cookie, cookieNoPath
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        verifyXML(body)
        cookie = con.getHeaderField('Set-Cookie')
        println cookie
        assert cookie: 'No cookie present, cannot keep session'
        cookieNoPath = cookie.split(';')[0]

        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult[0].promotion.code == RESTRICTED_PROMOTION_CODE
        assert response.potentialOrderPromotions.promotionResult[0].promotion.promotionType == RESTRICTED_PROMOTION_TYPE
        assert response.potentialOrderPromotions.promotionResult[0].promotion.description == RESTRICTED_PROMOTION_DESCRIPTION
        assert response.potentialOrderPromotions.promotionResult[0].promotion.endDate.toString().startsWith(RESTRICTED_PROMOTION_END_DATE)
        assert response.potentialOrderPromotions.promotionResult[0].promotion.couldFireMessages.string == RESTRICTED_PROMOTION_COULD_FIRE_MESSAGE
        assert response.potentialOrderPromotions.promotionResult[0].description == RESTRICTED_PROMOTION_COULD_FIRE_MESSAGE
    }

    @Test
    void testDisablePotentialOrderPromotionByCustomer() {
        def con, body, response, cookie, cookieNoPath
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        con = TestUtil.getSecureConnection('/cart', 'GET', 'XML', HttpURLConnection.HTTP_OK, null, null, access_token)
        body = con.inputStream.text
        verifyXML(body)
        cookie = con.getHeaderField('Set-Cookie')
        println cookie
        assert cookie: 'No cookie present, cannot keep session'
        cookieNoPath = cookie.split(';')[0]

        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 1

        con = TestUtil.getSecureConnection("/cart/promotion/${RESTRICTED_PROMOTION_CODE}", 'DELETE', 'XML', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        body = con.inputStream.text
        verifyXML(body)
        response = new XmlSlurper().parseText(body)
        assert response.potentialOrderPromotions.promotionResult.findAll { it.code = RESTRICTED_PROMOTION_CODE }.size() == 0
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testCartCreatePaymentInfo() {
        def con, response, postBody, cookieNoPath

        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)
        def aid = customerTests.createAddressJSON(access_token)

        //put something in a new cart
        cookieNoPath = addToCart(1934795, 2, null, access_token)

        //set the delivery address
        con = TestUtil.getSecureConnection('/cart/address/delivery/' + aid, 'PUT', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryAddress.id
        assert response.deliveryAddress.firstName == 'Sven'
        assert response.deliveryAddress.lastName == 'Haiges'
        assert response.deliveryAddress.titleCode == 'dr'
        assert response.deliveryAddress.title == 'Dr.'
        assert response.deliveryAddress.postalCode == '80331'
        assert response.deliveryAddress.town == 'Muenchen'
        assert response.deliveryAddress.line1 == 'Nymphenburger Str. 86 - Maillingerstrasse'
        assert response.deliveryAddress.country.name == 'Germany'
        assert response.deliveryAddress.country.isocode == 'DE'
        assert response.deliveryAddress.formattedAddress == 'Nymphenburger Str. 86 - Maillingerstrasse, 80331, Muenchen, Germany'

        //set a delivery mode
        con = TestUtil.getSecureConnection('/cart/deliverymodes/' + 'standard-gross', 'PUT', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryCost.currencyIso == 'USD'
        assert response.deliveryCost.priceType == 'BUY'
        assert response.deliveryCost.value == 8.99
        assert response.deliveryCost.formattedValue == '$8.99'

        //create a paymentinfo for this cart
        postBody = "accountHolderName=Sven+Haiges&cardNumber=4111111111111111&cardType=visa&expiryMonth=01&expiryYear=2113&saved=true&defaultPaymentInfo=true&billingAddress.titleCode=mr&billingAddress.firstName=sven&billingAddress.lastName=haiges&billingAddress.line1=test1&billingAddress.line2=test2&billingAddress.postalCode=12345&billingAddress.town=somecity&billingAddress.country.isocode=DE"
        con = TestUtil.getSecureConnection("/cart/paymentinfo", 'POST', 'JSON', HttpURLConnection.HTTP_OK, postBody, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.paymentInfo.id
        assert response.paymentInfo.subscriptionId == 'MockedSubscriptionID'
        assert response.paymentInfo.saved == true
        assert response.paymentInfo.defaultPaymentInfo == true
        assert response.paymentInfo.expiryMonth == '01'
        assert response.paymentInfo.expiryYear == '2113'
        assert response.paymentInfo.cardType.name == 'Visa'
        assert response.paymentInfo.cardType.code == 'visa'
        assert response.paymentInfo.accountHolderName == 'Sven Haiges'
        assert response.paymentInfo.cardNumber == '************1111'
        assert response.paymentInfo.billingAddress.id
        assert response.paymentInfo.billingAddress.lastName == 'haiges'
        assert response.paymentInfo.billingAddress.firstName == 'sven'
        assert response.paymentInfo.billingAddress.titleCode == 'mr'
        assert response.paymentInfo.billingAddress.title == "Mr"
        assert response.paymentInfo.billingAddress.country.name == 'Germany'
        assert response.paymentInfo.billingAddress.country.isocode == 'DE'
        assert response.paymentInfo.billingAddress.postalCode == '12345'
        assert response.paymentInfo.billingAddress.email == uid
        assert response.paymentInfo.billingAddress.formattedAddress == 'test1, test2, 12345, somecity, Germany'
        assert response.paymentInfo.billingAddress.town == 'somecity'
        assert response.paymentInfo.billingAddress.line1 == 'test1'
        assert response.paymentInfo.billingAddress.line2 == 'test2'
    }

    @Test
    void testRemoveDeliveryAddress() {
        def con, response, cookieNoPath
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)
        def aid = customerTests.createAddressJSON(access_token)

        // put something in a new cart
        cookieNoPath = addToCart(1934795, 1, null, access_token)

        // add delivery address
        con = TestUtil.getSecureConnection('/cart/address/delivery/' + aid, 'PUT', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryAddress != null

        // delete delivery address
        con = TestUtil.getSecureConnection('/cart/address/delivery', 'DELETE', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryAddress == null
    }

    @Test
    void testRemoveDeliveryMode() {
        def con, response, cookieNoPath
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)
        def aid = customerTests.createAddressJSON(access_token)

        // put something in a new cart
        cookieNoPath = addToCart(1934795, 1, null, access_token)

        // add delivery address
        con = TestUtil.getSecureConnection('/cart/address/delivery/' + aid, 'PUT', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryAddress != null

        // set delivery mode
        con = TestUtil.getSecureConnection('/cart/deliverymodes/' + 'standard-gross', 'PUT', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryCost != null

        // delete delivery address
        con = TestUtil.getSecureConnection('/cart/deliverymodes', 'DELETE', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryCost == null
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testCreatePaymentInfoWithoutCart() {
        def con, response, postBody, cookieNoPath

        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        postBody = "accountHolderName=Sven+Haiges&cardNumber=4111111111111111&cardType=visa&expiryMonth=01&expiryYear=2114&saved=true&defaultPaymentInfo=true&billingAddress.titleCode=mr&billingAddress.firstName=sven&billingAddress.lastName=haiges&billingAddress.line1=test1&billingAddress.line2=test2&billingAddress.postcode=12345&billingAddress.town=somecity&billingAddress.country.isocode=DE"
        con = TestUtil.getSecureConnection("/cart/paymentinfo", 'POST', 'XML', HttpURLConnection.HTTP_BAD_REQUEST, postBody, cookieNoPath, access_token)
        response = new XmlSlurper().parseText(con.errorStream.text)
        assert response.'class' == 'NoCheckoutCartException'
    }

    @Test
    void testInvalidPlaceOrder() {
        def con, response, cookieNoPath

        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        // put something in a new cart'
        cookieNoPath = addToCart(1934795, 1, null, access_token)

        con = TestUtil.getSecureConnection('/cart/placeorder', 'POST', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.created
        assert response.guestCustomer == false
    }

    @Test
    void testAuthorizedValidPlaceOrder() {
        def con, response, cookieNoPath, postBody

        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)
        def aid = customerTests.createAddressJSON(access_token)

        // put something in a new cart'
        cookieNoPath = addToCart(1934795, 1, null, access_token)

        // set the delivery address
        con = TestUtil.getSecureConnection('/cart/address/delivery/' + aid, 'PUT', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryAddress != null

        // set a delivery mode
        con = TestUtil.getSecureConnection('/cart/deliverymodes/' + 'standard-gross', 'PUT', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryCost != null

        // create a paymentinfo for this cart
        postBody = "accountHolderName=Sven+Haiges&cardNumber=4111111111111111&cardType=visa&expiryMonth=01&expiryYear=2114&saved=true&defaultPaymentInfo=true&billingAddress.titleCode=mr&billingAddress.firstName=sven&billingAddress.lastName=haiges&billingAddress.line1=test1&billingAddress.line2=test2&billingAddress.postalCode=12345&billingAddress.town=somecity&billingAddress.country.isocode=DE"
        con = TestUtil.getSecureConnection("/cart/paymentinfo", 'POST', 'JSON', HttpURLConnection.HTTP_OK, postBody, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.paymentInfo != null

        postBody = 'securityCode=123'
        con = TestUtil.getSecureConnection('/cart/authorize', 'POST', 'JSON', HttpURLConnection.HTTP_ACCEPTED, postBody, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);

        con = TestUtil.getSecureConnection('/cart/placeorder', 'POST', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.created
        assert response.guestCustomer == false
    }

    @Test
    void testGetSupportedDeliveryModes() {
        def con, response, cookieNoPath

        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)
        def aid = customerTests.createAddressJSON(access_token)

        // put something in a new cart'
        cookieNoPath = addToCart(1934795, 1, null, access_token)

        // set the delivery address
        con = TestUtil.getSecureConnection('/cart/address/delivery/' + aid, 'PUT', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.deliveryAddress != null

        // get supported delivery modes
        con = TestUtil.getSecureConnection('/cart/deliverymodes', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, true, false);
        assert response.deliveryModes.size() == 2

        def standardDeliveryMode = response.deliveryModes.find { it.code == 'standard-gross' };
        assert standardDeliveryMode.code == 'standard-gross'
        assert standardDeliveryMode.deliveryCost.value == 8.99
        assert standardDeliveryMode.deliveryCost.formattedValue == '$8.99'
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testApplyVoucherForCartByCustomer() {
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        //put something in a new cart'
        def cookieNoPath = addToCart(1934795, 2, null, access_token)

        def con = TestUtil.getConnection('/cart', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        def response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 223.68

        con = TestUtil.getSecureConnection("/cart/voucher/${PROMOTION_VOUCHER_CODE}", 'POST', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)

        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.appliedVouchers.size() == 1
        assert response.appliedVouchers[0].code == "abc"
        assert response.appliedVouchers[0].freeShipping == false
        assert response.appliedVouchers[0].voucherCode == PROMOTION_VOUCHER_CODE
        assert response.appliedVouchers[0].name == "New Promotional Voucher"
        assert response.appliedVouchers[0].description == "Promotion Voucher Description"
        assert response.appliedVouchers[0].value == 10
        assert response.appliedVouchers[0].valueString == '10.0%'
        assert response.appliedVouchers[0].valueFormatted == '10.0%'
        assert Math.round(response.appliedVouchers[0].appliedValue.value * 100) / 100 == 22.37
        assert response.appliedVouchers[0].appliedValue.priceType == 'BUY'
        assert response.appliedVouchers[0].appliedValue.currencyIso == 'USD'
        assert response.appliedVouchers[0].appliedValue.formattedValue == '$22.37'
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 201.31
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testApplyVoucherForCartByClient() {
        def access_token = TestUtil.getClientCredentialsToken()
        //put something in a new cart'
        def cookieNoPath = addToCart(1934795, 2, null, access_token)

        def con = TestUtil.getConnection('/cart', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        def response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 223.68

        con = TestUtil.getSecureConnection("/cart/voucher/${PROMOTION_VOUCHER_CODE}", 'POST', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)

        response = TestUtil.verifiedJSONSlurper(con, true, false);
        assert response.appliedVouchers.size() == 1
        assert response.appliedVouchers[0].code == "abc"
        assert response.appliedVouchers[0].freeShipping == false
        assert response.appliedVouchers[0].voucherCode == PROMOTION_VOUCHER_CODE
        assert response.appliedVouchers[0].name == "New Promotional Voucher"
        assert response.appliedVouchers[0].description == "Promotion Voucher Description"
        assert response.appliedVouchers[0].value == 10
        assert response.appliedVouchers[0].valueString == '10.0%'
        assert response.appliedVouchers[0].valueFormatted == '10.0%'
        assert Math.round(response.appliedVouchers[0].appliedValue.value * 100) / 100 == 22.37
        assert response.appliedVouchers[0].appliedValue.priceType == 'BUY'
        assert response.appliedVouchers[0].appliedValue.currencyIso == 'USD'
        assert response.appliedVouchers[0].appliedValue.formattedValue == '$22.37'
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 201.31
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testApplyRestrictedVoucherForCartByCustomer() {
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        // put something in a new cart
        def cookieNoPath = addToCart(1934795, 2, null, access_token)

        def con = TestUtil.getConnection('/cart', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        def response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value < 250

        // Should fail:
        con = TestUtil.getSecureConnection("/cart/voucher/${RESTRICTED_PROMOTION_VOUCHER_CODE}", 'POST', 'JSON', HttpURLConnection.HTTP_BAD_REQUEST, null, cookieNoPath, access_token)

        response = new JsonSlurper().parseText(con.errorStream.text)
        assert response.'class' == 'VoucherOperationException'

        // put one more product to meet the restriction (totalPrice >= 250)
        cookieNoPath = addToCart(1934795, 1, cookieNoPath, access_token)

        con = TestUtil.getConnection('/cart', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.totalItems == 1
        assert response.totalUnitCount == 3
        assert response.totalPrice.value >= 250

        con = TestUtil.getSecureConnection("/cart/voucher/${RESTRICTED_PROMOTION_VOUCHER_CODE}", 'POST', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)

        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.appliedVouchers.size() == 1
        assert response.appliedVouchers[0].code == "abr"
        assert response.appliedVouchers[0].freeShipping == false
        assert response.appliedVouchers[0].voucherCode == RESTRICTED_PROMOTION_VOUCHER_CODE
        assert response.appliedVouchers[0].value == 10
        assert response.totalItems == 1
        assert response.totalUnitCount == 3
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testApplyAbsoluteVoucherForCartByCustomer() {
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        //put something in a new cart'
        def cookieNoPath = addToCart(1934795, 2, null, access_token)

        def con = TestUtil.getConnection('/cart', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        def response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 223.68

        con = TestUtil.getSecureConnection("/cart/voucher/${ABSOLUTE_VOUCHER_CODE}", 'POST', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)

        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.appliedVouchers.size() == 1
        assert response.appliedVouchers[0].code == "xyz"
        assert response.appliedVouchers[0].freeShipping == true
        assert response.appliedVouchers[0].voucherCode == ABSOLUTE_VOUCHER_CODE
        assert response.appliedVouchers[0].name == "New Voucher"
        assert response.appliedVouchers[0].description == "Voucher Description"
        assert response.appliedVouchers[0].value == 15
        assert response.appliedVouchers[0].valueString == '15.0 USD'
        assert response.appliedVouchers[0].valueFormatted == '15.0 USD'
        assert response.appliedVouchers[0].currency.isocode == "USD"
        assert response.appliedVouchers[0].currency.name == 'US Dollar'
        assert response.appliedVouchers[0].currency.symbol == '$'
        assert response.appliedVouchers[0].appliedValue.value == 15.0
        assert response.appliedVouchers[0].appliedValue.priceType == 'BUY'
        assert response.appliedVouchers[0].appliedValue.currencyIso == 'USD'
        assert response.appliedVouchers[0].appliedValue.formattedValue == '$15.00'
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 208.68
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testApplyAbsoluteVoucherForCartByClient() {
        def access_token = TestUtil.getClientCredentialsToken()

        //put something in a new cart'
        def cookieNoPath = addToCart(1934795, 2, null, access_token)

        def con = TestUtil.getConnection('/cart', 'GET', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath)
        def response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 223.68

        con = TestUtil.getSecureConnection("/cart/voucher/${ABSOLUTE_VOUCHER_CODE}", 'POST', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)

        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.appliedVouchers.size() == 1
        assert response.appliedVouchers[0].code == "xyz"
        assert response.appliedVouchers[0].freeShipping == true
        assert response.appliedVouchers[0].voucherCode == ABSOLUTE_VOUCHER_CODE
        assert response.appliedVouchers[0].name == "New Voucher"
        assert response.appliedVouchers[0].description == "Voucher Description"
        assert response.appliedVouchers[0].value == 15
        assert response.appliedVouchers[0].valueString == '15.0 USD'
        assert response.appliedVouchers[0].valueFormatted == '15.0 USD'
        assert response.appliedVouchers[0].currency.isocode == "USD"
        assert response.appliedVouchers[0].currency.name == 'US Dollar'
        assert response.appliedVouchers[0].currency.symbol == '$'
        assert response.appliedVouchers[0].appliedValue.value == 15.0
        assert response.appliedVouchers[0].appliedValue.priceType == 'BUY'
        assert response.appliedVouchers[0].appliedValue.currencyIso == 'USD'
        assert response.appliedVouchers[0].appliedValue.formattedValue == '$15.00'
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 208.68
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testApplyNotExistingVoucherForCartByCustomer() {
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        //put something in a new cart'
        def cookieNoPath = addToCart(1934795, 1, null, access_token)

        def con = TestUtil.getSecureConnection("/cart/voucher/${NOT_EXISTING_VOUCHER_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_BAD_REQUEST, null, cookieNoPath, access_token)

        def response = new XmlSlurper().parseText(con.errorStream.text)
        assert response.'class' == 'VoucherOperationException'
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testApplyNotExistingVoucherForCartByClient() {
        def access_token = TestUtil.getClientCredentialsToken()

        //put something in a new cart'
        def cookieNoPath = addToCart(1934795, 1, null, access_token)

        def con = TestUtil.getSecureConnection("/cart/voucher/${NOT_EXISTING_VOUCHER_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_BAD_REQUEST, null, cookieNoPath, access_token)

        def response = new XmlSlurper().parseText(con.errorStream.text)
        assert response.'class' == 'VoucherOperationException'
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testApplyVoucherWithoutCartByCustomer() {
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        def cookieNoPath;

        def con = TestUtil.getSecureConnection("/cart/voucher/${PROMOTION_VOUCHER_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_BAD_REQUEST, null, cookieNoPath, access_token)

        def response = new XmlSlurper().parseText(con.errorStream.text)
        assert response.'class' == 'NoCheckoutCartException'
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testApplyVoucherWithoutCartByClient() {
        def access_token = TestUtil.getClientCredentialsToken()

        def cookieNoPath;

        def con = TestUtil.getSecureConnection("/cart/voucher/${PROMOTION_VOUCHER_CODE}", 'POST', 'XML', HttpURLConnection.HTTP_BAD_REQUEST, null, cookieNoPath, access_token)

        def response = new XmlSlurper().parseText(con.errorStream.text)
        assert response.'class' == 'NoCheckoutCartException'
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testRealeseVoucherForCartByCustomer() {
        def customerTests = new CustomerTests()
        def uid = customerTests.registerUser()
        def access_token = TestUtil.getAccessToken(uid, PASSWORD)

        //put something in a new cart'
        def cookieNoPath = addToCart(1934795, 2, null, access_token)

        def con = TestUtil.getSecureConnection("/cart/voucher/${PROMOTION_VOUCHER_CODE}", 'POST', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        def response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.appliedVouchers.size() == 1
        assert response.appliedVouchers[0].code == "abc"
        assert response.appliedVouchers[0].voucherCode == PROMOTION_VOUCHER_CODE
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 201.31

        con = TestUtil.getSecureConnection("/cart/voucher/${PROMOTION_VOUCHER_CODE}", 'DELETE', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.appliedVouchers.size() == 0
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 223.68
    }

    @Test
    @Category(AvoidCollectingOutputFromTest.class)
    void testRealeseVoucherForCartByClient() {
        def access_token = TestUtil.getClientCredentialsToken()

        //put something in a new cart'
        def cookieNoPath = addToCart(1934795, 2, null, access_token)

        def con = TestUtil.getSecureConnection("/cart/voucher/${PROMOTION_VOUCHER_CODE}", 'POST', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        def response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.appliedVouchers.size() == 1
        assert response.appliedVouchers[0].code == "abc"
        assert response.appliedVouchers[0].voucherCode == PROMOTION_VOUCHER_CODE
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 201.31

        con = TestUtil.getSecureConnection("/cart/voucher/${PROMOTION_VOUCHER_CODE}", 'DELETE', 'JSON', HttpURLConnection.HTTP_OK, null, cookieNoPath, access_token)
        response = TestUtil.verifiedJSONSlurper(con, false, false);
        assert response.appliedVouchers.size() == 0
        assert response.totalItems == 1
        assert response.totalUnitCount == 2
        assert response.totalPrice.value == 223.68
    }

    /**
     * Helper method for adding product to the cart
     *
     * @param code Product code
     * @param qty Quantity of products
     * @param cookie Cookie
     * @param access_token Access token for secure connection
     *
     * @return cookie without path
     */
    def addToCart(code, qty = 1, cookie = null, access_token = null) {
        //add something to a cart
        def postBody = "code=${code}&qty=${qty}"

        def con
        if (access_token != null)
            con = TestUtil.getSecureConnection('/cart/entry', 'POST', 'XML', HttpURLConnection.HTTP_OK, postBody, cookie, access_token)
        else
            con = TestUtil.getConnection('/cart/entry', 'POST', 'XML', HttpURLConnection.HTTP_OK, postBody, cookie)

        def body = con.inputStream.text
        verifyXML(body)
        def response = new XmlSlurper().parseText(body)
        assert response.statusCode == 'success'
        assert response.quantityAdded == qty

        //check for cookie, extract it for next request
        def new_cookie = con.getHeaderField('Set-Cookie')
        println new_cookie
        def ret = cookie;
        if (new_cookie != null) {
            def cookie_split = new_cookie.split(';')
            if (cookie_split[0].split('=')[0] == 'JSESSIONID') {
                ret = cookie_split[0];
            }
        }
        assert ret: 'No cookie present, cannot keep session';

        return ret;
    }
}