/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jan 5, 2015 4:45:55 PM                      ---
 * ----------------------------------------------------------------
 */
package com.acc.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedYcommercewebservicesConstants
{
	public static final String EXTENSIONNAME = "bncwebservices";
	public static class TC
	{
		public static final String OLDCARTREMOVALCRONJOB = "OldCartRemovalCronJob".intern();
		public static final String PRODUCTEXPRESSUPDATECLEANERCRONJOB = "ProductExpressUpdateCleanerCronJob".intern();
	}
	public static class Attributes
	{
		// no constants defined.
	}
	
	protected GeneratedYcommercewebservicesConstants()
	{
		// private constructor
	}
	
	
}
