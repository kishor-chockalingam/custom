/**
 * 
 */
package de.hybris.platform.acceleratorstorefrontcommons.forms;

/**
 * @author swapnil.a.pandey
 * 
 */
public class AddToWishlistForm
{
	private String code;

	/**
	 * @return the code
	 */
	public String getCode()
	{
		return code;
	}

	/**
	 * @param code
	 *           the code to set
	 */
	public void setCode(final String code)
	{
		this.code = code;
	}
}
